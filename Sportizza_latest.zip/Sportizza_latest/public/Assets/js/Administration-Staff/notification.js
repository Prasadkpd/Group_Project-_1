      //popup notification section
      function open_popup_notification(){
        var form=document.getElementById("popup_notification");
          
        form.style.display = "block";
      }
      function close_popup_notification(){
        var form=document.getElementById("popup_notification");
          
        form.style.display = "none";
      } 