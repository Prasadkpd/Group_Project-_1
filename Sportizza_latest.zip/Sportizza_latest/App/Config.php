<?php


namespace App;


class Config
{
    const DB_HOST = 'localhost';

    const DB_NAME = 'sportizza';

    const DB_USER = 'root';

    const DB_PASSWORD = '';

    const SHOW_ERRORS = true;
}