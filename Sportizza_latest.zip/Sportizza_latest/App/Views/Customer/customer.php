<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Customer</title>
</head>
<body>
    <h1>Welcome</h1>
    <p>Hello Man!</p>
</body>
</html>